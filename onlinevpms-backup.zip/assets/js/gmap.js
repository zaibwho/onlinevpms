

  // This example displays a marker at the center of Australia.
// When the user clicks the marker, an info window opens.
function initMap() {
  const home = { lat: 31.527907, lng: 74.291192 };
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 18,
    center: home,
  });
 /* const contentString =
    "<p>Home</p> ";
  const infowindow = new google.maps.InfoWindow({
    content: contentString,
  });*/

  
}


