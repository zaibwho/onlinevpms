<?php
$con=mysqli_connect("localhost", "onlinevpms_onlinevpms", "cs?ncbae2020", "onlinevpms_std");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
