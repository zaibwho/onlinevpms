  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; 2022. FYP-ADP Shahzaib Bin Shahid-2203185, Samah Khan-2203140
                    </div>
                    
                </div>
            </div>
        </footer>