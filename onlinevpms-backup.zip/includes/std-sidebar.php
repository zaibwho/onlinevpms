<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"><i class="menu-icon fa fa-laptop"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="add-vehicle.php"> <i class="menu-icon fa-solid fa-plus"></i>Add Vehicle</a>
                    </li>
                    <li>
                        <a href="vehicle-log.php"><i class="menu-icon fa-solid fa-file-lines"></i>Vehicle Logs</a>
                    </li>
                    <li>
                        <a href="delete-vehicle.php"><i class = "menu-icon fa-solid fa-trash"></i>Delete Vehicle</a>
                    </li>
                    <li class = "logout-li">
                        <a class = "stdlogout" href = "logout.php"><i class = "menu-icon fa-solid fa-arrow-right-from-bracket"></i>Logout</a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>